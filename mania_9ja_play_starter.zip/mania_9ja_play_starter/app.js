const express = require("express");
const crypto = require("crypto");

const app = express();
const PORT = process.env.PORT || 3000;

const WA_TOKEN = process.env.WA_TOKEN;
const PHONE_NUMBER_ID = process.env.PHONE_NUMBER_ID;
const VERIFY_TOKEN = process.env.VERIFY_TOKEN;
const APP_SECRET = process.env.APP_SECRET;
const GRAPH_API_VERSION = process.env.GRAPH_API_VERSION || "v26.0";

// Beginner prototype: sessions and scores are kept in memory.
// They reset if this server restarts. We can add a database later.
const sessions = new Map();
const scores = new Map();
const optedOut = new Set();
const processedMessageIds = new Set();

const quizQuestions = [
  {
    text: "Q1. What is the capital of Nigeria?",
    answer: "B",
    explanation: "Nigeria's capital is Abuja.",
    options: [
      { id: "quiz_0_A", title: "A. Lagos" },
      { id: "quiz_0_B", title: "B. Abuja" },
      { id: "quiz_0_C", title: "C. Kano" },
      { id: "quiz_0_D", title: "D. Ibadan" }
    ]
  },
  {
    text: "Q2. What is Nigeria's official currency?",
    answer: "C",
    explanation: "Nigeria uses the naira.",
    options: [
      { id: "quiz_1_A", title: "A. Cedi" },
      { id: "quiz_1_B", title: "B. Rand" },
      { id: "quiz_1_C", title: "C. Naira" },
      { id: "quiz_1_D", title: "D. Shilling" }
    ]
  },
  {
    text: "Q3. Benin City is the capital of which state?",
    answer: "A",
    explanation: "Benin City is the capital of Edo State.",
    options: [
      { id: "quiz_2_A", title: "A. Edo" },
      { id: "quiz_2_B", title: "B. Delta" },
      { id: "quiz_2_C", title: "C. Ondo" },
      { id: "quiz_2_D", title: "D. Ekiti" }
    ]
  },
  {
    text: "Q4. Which river meets the River Niger at Lokoja?",
    answer: "D",
    explanation: "The River Benue meets the Niger at Lokoja.",
    options: [
      { id: "quiz_3_A", title: "A. Osun" },
      { id: "quiz_3_B", title: "B. Kaduna" },
      { id: "quiz_3_C", title: "C. Ogun" },
      { id: "quiz_3_D", title: "D. Benue" }
    ]
  },
  {
    text: "Q5. How many states are in Nigeria?",
    answer: "B",
    explanation: "Nigeria has 36 states.",
    options: [
      { id: "quiz_4_A", title: "A. 30" },
      { id: "quiz_4_B", title: "B. 36" },
      { id: "quiz_4_C", title: "C. 37" },
      { id: "quiz_4_D", title: "D. 40" }
    ]
  }
];

const emojiChallenges = [
  {
    prompt: "😂 EMOJI DECODER — Round 1\n\n🍚 + 🍅 + 🌶️\n\nWhat Nigerian food is this?",
    answers: ["jollof", "jollof rice"],
    reveal: "Jollof rice!"
  },
  {
    prompt: "😂 EMOJI DECODER — Round 2\n\n🦁 + 👑\n\nDecode the movie title.",
    answers: ["the lion king", "lion king"],
    reveal: "The Lion King!"
  },
  {
    prompt: "😂 EMOJI DECODER — Round 3\n\n🧊 + 🤴\n\nWhich Nigerian rapper's stage name is this?",
    answers: ["ice prince", "iceprince", "ice prince zamani"],
    reveal: "Ice Prince!"
  }
];

function normalizeAnswer(value) {
  return String(value || "")
    .toLowerCase()
    .trim()
    .replace(/[^a-z0-9]/g, "");
}

function verifySignature(rawBody, signatureHeader) {
  if (!APP_SECRET || !signatureHeader || !rawBody) return false;
  const expected = "sha256=" + crypto
    .createHmac("sha256", APP_SECRET)
    .update(rawBody)
    .digest("hex");

  const actualBuffer = Buffer.from(signatureHeader);
  const expectedBuffer = Buffer.from(expected);
  return actualBuffer.length === expectedBuffer.length &&
    crypto.timingSafeEqual(actualBuffer, expectedBuffer);
}

async function sendWhatsApp(to, payload) {
  if (!WA_TOKEN || !PHONE_NUMBER_ID) {
    console.error("Missing WA_TOKEN or PHONE_NUMBER_ID in environment secrets.");
    return;
  }

  const url = `https://graph.facebook.com/${GRAPH_API_VERSION}/${PHONE_NUMBER_ID}/messages`;
  const response = await fetch(url, {
    method: "POST",
    headers: {
      Authorization: `Bearer ${WA_TOKEN}`,
      "Content-Type": "application/json"
    },
    body: JSON.stringify({
      messaging_product: "whatsapp",
      recipient_type: "individual",
      to,
      ...payload
    })
  });

  if (!response.ok) {
    // Do not print access tokens or other secrets.
    console.error(`WhatsApp API returned HTTP ${response.status}. Check the Meta dashboard/logs.`);
  }
}

function sendText(to, body) {
  return sendWhatsApp(to, {
    type: "text",
    text: { body, preview_url: false }
  });
}

function sendList(to, header, body, buttonText, rows) {
  return sendWhatsApp(to, {
    type: "interactive",
    interactive: {
      type: "list",
      header: { type: "text", text: header },
      body: { text: body },
      footer: { text: "MANIA 9JA PLAY 🇳🇬" },
      action: {
        button: buttonText,
        sections: [{ title: "Choose one", rows }]
      }
    }
  });
}

function sendMenu(to) {
  return sendList(
    to,
    "MANIA 9JA PLAY 🎮",
    "Welcome! What do you want to play?",
    "Choose game",
    [
      { id: "menu_quiz", title: "🇳🇬 9ja Quiz", description: "Test your Naija knowledge" },
      { id: "menu_emoji", title: "😂 Emoji Decoder", description: "Crack the emoji clues" },
      { id: "menu_scores", title: "🏆 My Scores", description: "Check your points" }
    ]
  );
}

function sendQuizQuestion(to, session) {
  const question = quizQuestions[session.index];
  return sendList(
    to,
    "🇳🇬 9ja Quiz",
    question.text,
    "Choose answer",
    question.options
  );
}

function sendEmojiQuestion(to, session) {
  const challenge = emojiChallenges[session.index];
  return sendText(to, challenge.prompt + "\n\nType your answer.");
}

async function finishGame(to, session, gameName) {
  const previousTotal = scores.get(to) || 0;
  scores.set(to, previousTotal + session.score);
  sessions.delete(to);

  await sendText(
    to,
    `🏁 ${gameName} complete!\nYou scored ${session.score} point(s).\nYour total points: ${scores.get(to)}.\n\nType MENU to play again.`
  );
}

async function handleIncoming(to, text, interactiveId) {
  const raw = String(text || "").trim();
  const input = raw.toLowerCase();
  const id = String(interactiveId || "");

  if (input === "stop") {
    optedOut.add(to);
    sessions.delete(to);
    return sendText(to, "You've paused MANIA 9JA PLAY replies. Type START whenever you want to play again.");
  }

  if (optedOut.has(to)) {
    if (input === "start") {
      optedOut.delete(to);
      return sendMenu(to);
    }
    return;
  }

  if (input === "start" || input === "hi" || input === "hello" || input === "hey" || input === "menu") {
    sessions.delete(to);
    return sendMenu(to);
  }

  if (id === "menu_scores" || input === "scores" || input === "score") {
    return sendText(to, `🏆 Your total score is ${scores.get(to) || 0} point(s).\nType MENU to play.`);
  }

  if (id === "menu_quiz" || input === "1" || input === "quiz" || input === "9ja quiz") {
    const session = { mode: "quiz", index: 0, score: 0 };
    sessions.set(to, session);
    return sendQuizQuestion(to, session);
  }

  if (id === "menu_emoji" || input === "2" || input === "emoji" || input === "emoji decoder") {
    const session = { mode: "emoji", index: 0, score: 0 };
    sessions.set(to, session);
    return sendEmojiQuestion(to, session);
  }

  const session = sessions.get(to);
  if (!session) {
    return sendText(to, "Type START to open MANIA 9JA PLAY.");
  }

  if (session.mode === "quiz") {
    let answer = "";
    const match = id.match(/^quiz_(\d+)_([A-D])$/);
    if (match && Number(match[1]) === session.index) {
      answer = match[2];
    } else if (/^[a-d]$/i.test(raw)) {
      answer = raw.toUpperCase();
    } else {
      return sendText(to, "Please tap one of the answer options, or type A, B, C or D.");
    }

    const question = quizQuestions[session.index];
    const correct = answer === question.answer;
    if (correct) session.score += 1;

    await sendText(
      to,
      `${correct ? "✅ Correct!" : "❌ Not quite."} ${question.explanation}\n\nRound score: ${session.score}`
    );

    session.index += 1;
    if (session.index >= quizQuestions.length) {
      return finishGame(to, session, "9ja Quiz");
    }
    return sendQuizQuestion(to, session);
  }

  if (session.mode === "emoji") {
    const challenge = emojiChallenges[session.index];
    const guess = normalizeAnswer(raw);
    const correct = challenge.answers.some(a => normalizeAnswer(a) === guess);
    if (correct) session.score += 1;

    await sendText(
      to,
      `${correct ? "✅ Correct!" : "❌ The answer was"} ${challenge.reveal}\n\nRound score: ${session.score}`
    );

    session.index += 1;
    if (session.index >= emojiChallenges.length) {
      return finishGame(to, session, "Emoji Decoder");
    }
    return sendEmojiQuestion(to, session);
  }
}

// Public health endpoint for checking that the server is running.
app.get("/", (_req, res) => {
  res.status(200).send("MANIA 9JA PLAY starter is running.");
});

app.get("/webhook", (req, res) => {
  const mode = req.query["hub.mode"];
  const token = req.query["hub.verify_token"];
  const challenge = req.query["hub.challenge"];

  if (mode === "subscribe" && token === VERIFY_TOKEN && challenge) {
    return res.status(200).send(challenge);
  }
  return res.sendStatus(403);
});

// Use raw body so Meta's signature can be verified before JSON parsing.
app.post("/webhook", express.raw({ type: "application/json" }), async (req, res) => {
  const rawBody = req.body;

  if (!Buffer.isBuffer(rawBody) || !verifySignature(rawBody, req.get("x-hub-signature-256"))) {
    return res.sendStatus(403);
  }

  let body;
  try {
    body = JSON.parse(rawBody.toString("utf8"));
  } catch (_error) {
    return res.sendStatus(400);
  }

  // Acknowledge quickly; then process the message payload.
  res.sendStatus(200);

  try {
    const entries = body.entry || [];
    for (const entry of entries) {
      for (const change of (entry.changes || [])) {
        const value = change.value || {};
        for (const message of (value.messages || [])) {
          if (!message.id || processedMessageIds.has(message.id)) continue;
          processedMessageIds.add(message.id);

          // Keep the de-duplication set bounded.
          if (processedMessageIds.size > 2000) {
            const oldest = processedMessageIds.values().next().value;
            processedMessageIds.delete(oldest);
          }

          const from = message.from;
          let text = "";
          let interactiveId = "";

          if (message.type === "text") {
            text = message.text?.body || "";
          } else if (message.type === "interactive") {
            const reply = message.interactive?.button_reply || message.interactive?.list_reply;
            text = reply?.title || "";
            interactiveId = reply?.id || "";
          }

          if (from && (text || interactiveId)) {
            await handleIncoming(from, text, interactiveId);
          }
        }
      }
    }
  } catch (error) {
    console.error("Webhook message processing failed:", error.message);
  }
});

app.listen(PORT, () => {
  console.log(`MANIA 9JA PLAY starter listening on port ${PORT}`);
});