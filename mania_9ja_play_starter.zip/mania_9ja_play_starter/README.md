# MANIA 9JA PLAY — WhatsApp starter

This is a **starter prototype**, not a deployed/live bot. It begins with:
- 9ja Quiz (5 questions, tap-to-answer list)
- Emoji Decoder (3 clues, type the answer)
- A simple menu and in-memory scores
- `STOP` and `START` commands
- Webhook verification and request-signature checking

## Important limitations

- Player sessions and scores are kept in memory. They reset if the server restarts.
- You need a Meta WhatsApp Cloud API test setup and a public HTTPS webhook URL before messages can reach the app.
- Use only your own test number or people who knowingly opt in. This prototype does not send unsolicited messages.
- Never paste an access token, app secret, or verification code into chat. Put credentials only in your host's private Secrets/Environment Variables panel.

## Environment secrets

Set these in the hosting platform's private Secrets/Environment Variables panel:

- `WA_TOKEN` — Meta access token (secret)
- `PHONE_NUMBER_ID` — WhatsApp phone-number ID shown in Meta's API setup
- `VERIFY_TOKEN` — a secret phrase you invent for webhook verification; it is not the Meta access token
- `APP_SECRET` — Meta app secret, used to verify webhook signatures
- `GRAPH_API_VERSION` — `v26.0` is the default in this starter; check Meta's current API version before deploying

Do not put real secrets in `app.js`, README, screenshots, or public posts.

## Run

1. Create a Node.js project on a host such as Replit.
2. Add `app.js` and `package.json` from this folder.
3. Add the environment secrets above.
4. Run `npm install`, then `npm start`.
5. The home route should show: `MANIA 9JA PLAY starter is running.`
6. Once your host provides a public HTTPS address, use `https://YOUR-APP-ADDRESS/webhook` as the Meta webhook callback URL.
7. Use the same `VERIFY_TOKEN` in the Meta webhook setup, verify the callback, then subscribe to the WhatsApp `messages` webhook field.

The exact Meta dashboard labels can change. Use the WhatsApp API setup panel in your Meta app.

## Player commands

- `START`, `HI`, or `MENU` — show game menu
- `1` or `QUIZ` — start 9ja Quiz
- `2` or `EMOJI` — start Emoji Decoder
- `SCORE` — view total score
- `STOP` — pause bot replies
- `START` after `STOP` — resume

## Current quiz content

The first five questions are simple Nigeria facts and can be replaced/expanded after the first test round.